from pynq import Overlay
import ipywidgets as ipw
#import signal
import os
import xrfdc
import xrfclk

# Import overlay specific drivers
from rfsoc_nrssb import inspector
from rfsoc_nrssb import ofdm
from rfsoc_nrssb import clocks


class Overlay(Overlay):
    """
    """
    
    def __init__(self, bitfile_name=None, init_rf_clks=True, **kwargs):
        """
        """

        # Generate default bitfile name
        if bitfile_name is None:
            this_dir = os.path.dirname(__file__)
            bitfile_name = os.path.join(this_dir, 'rfsoc_nrssb', 'bitstream', 'rfsoc_nrssb.bit')

        # Create Overlay
        super().__init__(bitfile_name, **kwargs)

        # Determine board and set PLL appropriately
        board = os.environ['BOARD']
        
        # Extract friendly dataconverter names
        if board == 'RFSoC4x2':
            self.dac_tile = self.rfdc.dac_tiles[2]
            self.dac_block = self.dac_tile.blocks[0]
            self.adc_tile = self.rfdc.adc_tiles[2]
            self.adc_block = self.adc_tile.blocks[1]
        elif board in ['ZCU208', 'ZCU216']:
            self.dac_tile = self.rfdc.dac_tiles[2]
            self.dac_block = self.dac_tile.blocks[0]
            self.adc_tile = self.rfdc.adc_tiles[1]
            self.adc_block = self.adc_tile.blocks[0]
        elif board == 'RFSoC2x2':
            self.dac_tile = self.rfdc.dac_tiles[1]
            self.dac_block = self.dac_tile.blocks[0]
            self.adc_tile = self.rfdc.adc_tiles[2]
            self.adc_block = self.adc_tile.blocks[0]
        elif board == 'ZCU111':
            self.dac_tile = self.rfdc.dac_tiles[1]
            self.dac_block = self.dac_tile.blocks[2]
            self.adc_tile = self.rfdc.adc_tiles[0]
            self.adc_block = self.adc_tile.blocks[0]
        else:
            raise RuntimeError('Unknown error occurred.') # shouldn't get here
        
        # Start up LMX clock
        if init_rf_clks:
            clocks.set_custom_lmclks()

        if board == 'ZCU216':
            fs = 1920.00
        else:
            fs = 3840.00

        self.configure_adcs(sample_freq=fs)
        #self.configure_dacs()
        self.inspector = self.InspectorSSB
        
    def configure_adcs(self, pll_freq=384.00, sample_freq=3840.00, nyquist_zone=1, centre_freq=-600):
        """
        """
        
        self.adc_tile.DynamicPLLConfig(1, pll_freq, sample_freq)
        self.adc_block.NyquistZone = nyquist_zone
        self.adc_block.MixerSettings = {
            'CoarseMixFreq'  : xrfdc.COARSE_MIX_BYPASS,
            'EventSource'    : xrfdc.EVNT_SRC_TILE,
            'FineMixerScale' : xrfdc.MIXER_SCALE_1P0,
            'Freq'           : centre_freq,
            'MixerMode'      : xrfdc.MIXER_MODE_R2C,
            'MixerType'      : xrfdc.MIXER_TYPE_FINE,
            'PhaseOffset'    : 0.0
        }
        self.adc_block.UpdateEvent(xrfdc.EVENT_MIXER)
        self.adc_tile.SetupFIFO(True)
        

    def configure_dacs(self, pll_freq=384.00, sample_freq=3840.00, nyquist_zone=1, centre_freq=600):
        """
        """
        
        self.dac_tile.DynamicPLLConfig(1, pll_freq, sample_freq)
        self.dac_block.NyquistZone = nyquist_zone
        self.dac_block.MixerSettings = {
            'CoarseMixFreq'  : xrfdc.COARSE_MIX_BYPASS,
            'EventSource'    : xrfdc.EVNT_SRC_IMMEDIATE,
            'FineMixerScale' : xrfdc.MIXER_SCALE_1P0,
            'Freq'           : centre_freq,
            'MixerMode'      : xrfdc.MIXER_MODE_C2R,
            'MixerType'      : xrfdc.MIXER_TYPE_FINE,
            'PhaseOffset'    : 0.0
        }
        self.dac_block.UpdateEvent(xrfdc.EVENT_MIXER)
        self.dac_tile.SetupFIFO(True)
        
    def configure_inspectors(self, shape=(1024,)):
        """
        """

        self.inspector.set_shape(shape=shape)     

    def nrssb_application(self):
        """
        """
        
        self.inspector.constellation_plot()
        self.inspector.get_frame()
