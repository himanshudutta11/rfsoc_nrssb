/*
 * File Name:         C:\Kiran\Project4\IP\ipcore\SSBDetect_ip_v1_0\include\SSBDetect_ip_addr.h
 * Description:       C Header File
 * Created:           2024-05-25 12:09:50
*/

#ifndef SSBDETECT_IP_H_
#define SSBDETECT_IP_H_

#define  IPCore_Reset_SSBDetect_ip                           0x0  //write 0x1 to bit 0 to reset IP core
#define  IPCore_Enable_SSBDetect_ip                          0x4  //enabled (by default) when bit 0 is 0x1
#define  IPCore_PacketSize_AXI4_Stream_Master_SSBDetect_ip   0x8  //Packet size for AXI4-Stream Master interface, the default value is 1024. The TLAST output signal of the AXI4-Stream Master interface is generated based on the packet size.
#define  IPCore_Timestamp_SSBDetect_ip                       0xC  //contains unique IP timestamp (yymmddHHMM): 2405251209
#define  scsSSB_Data_SSBDetect_ip                            0x100  //data register for Inport scsSSB
#define  startIn_Data_SSBDetect_ip                           0x108  //data register for Inport startIn
#define  done_Data_SSBDetect_ip                              0x110  //data register for Outport done

#endif /* SSBDETECT_IP_H_ */
